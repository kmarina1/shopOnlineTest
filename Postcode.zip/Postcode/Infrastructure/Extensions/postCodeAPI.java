package Extensions;



import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.xml.sax.SAXException;


import Utilities.commonOps;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class postCodeAPI extends commonOps
{

	private static Response getResponse(String address) throws SAXException, ParserConfigurationException, IOException
	
	{
		resp=httpRequest.get(address);
		return resp;
		
	}
	private static void printCountryAndRegion (Response resp)
	{
		System.out.println("*** The country is: "+resp.jsonPath().getString("result.country"));
		System.out.println("*** The region is: "+resp.jsonPath().getString("result.region"));
	}
	public static void validateCode (String address) throws SAXException, ParserConfigurationException, IOException
	{
		try {
		Response resp = getResponse(address);
		String isCodeValid = resp.jsonPath().getString("result");
		System.out.println("*** The code validation is: "+ isCodeValid);
		assertTrue(isCodeValid.contains("true"));
		}
		catch(AssertionError e)
		{
			fail("The postcode does not exist: "+e);
		}
	}
	
	public static void getCountryAndRegionByCode (String address) throws SAXException, ParserConfigurationException, IOException
	{
		Response resp = getResponse(address);
		printCountryAndRegion(resp);
	}
	
	public static void getCountryAndRegionByNearCodes(String address) throws SAXException, ParserConfigurationException, IOException
	{
		resp=httpRequest.get(address);
		JsonPath jp = resp.jsonPath();
		List <String> allCodesClause = jp.getList("result.postcode");
		for(String code:allCodesClause )
		{
			resp = getResponse(addressWithCode(code));
			printCountryAndRegion(resp);
		}
	
	}
	public static String addressWithCode (String postCode) throws SAXException, ParserConfigurationException, IOException 
	{
		String urlResourceAndcode=getData("API_Resource")+"/"+postCode;
		return urlResourceAndcode;
	}
	public static String addressWithCodeAndOutput (String postCode, String outPut) throws SAXException, ParserConfigurationException, IOException
	{
		String urlResourceCodeAndOutput = addressWithCode(postCode)+"/"+outPut;
		return urlResourceCodeAndOutput;
	}
	
}
