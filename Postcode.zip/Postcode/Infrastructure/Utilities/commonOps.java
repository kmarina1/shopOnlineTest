package Utilities;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;



import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;



import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;



import io.restassured.RestAssured;


public class commonOps extends base
	{
	public static void initAPI() throws SAXException, ParserConfigurationException, IOException
	{
		RestAssured.baseURI = getData("API_URL");
		httpRequest = RestAssured.given();
	}
	public static String getData (String nodeName) throws SAXException, ParserConfigurationException, IOException
	{
		File fXmlFile = new File("./Configuration/DataConfig.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder=dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();
		return doc.getElementsByTagName(nodeName).item(0).getTextContent();
	}
	
	
	
	@BeforeMethod
	public void doBeforeMethod(Method method) throws SAXException, ParserConfigurationException, IOException
	{
		
		initAPI();
		System.out.println("---------------Starting Test------------------");
		
		
	}
	


	
}
