package Utilities;



import org.json.simple.JSONObject;


import io.restassured.response.Response;





import io.restassured.specification.RequestSpecification;

public class base 
{

public static RequestSpecification httpRequest;
public static JSONObject requestParams = new JSONObject();
public static Response resp;


}

