package Tests;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;


import Extensions.postCodeAPI;

import Utilities.commonOps;



@Test
public class testPostCode extends commonOps
{
	

	public void test01_countryAndRegionByCode() throws SAXException, ParserConfigurationException, IOException, InterruptedException 
	{
		postCodeAPI.getCountryAndRegionByCode(postCodeAPI.addressWithCode("CB3 0FA"));
		
	}
	public void test02_nearCountryAndRegionByCode() throws SAXException, ParserConfigurationException, IOException, InterruptedException 
	{
		
		postCodeAPI.getCountryAndRegionByNearCodes(postCodeAPI.addressWithCodeAndOutput("CB3 0FA", "nearest"));
	}
	public void test03_validateGivenCode() throws SAXException, ParserConfigurationException, IOException, InterruptedException 
	{
		
		postCodeAPI.validateCode(postCodeAPI.addressWithCodeAndOutput("CB3 0FA", "validate"));
	}
	
	
	
	

}
