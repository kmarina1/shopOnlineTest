package Tests;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import Extensions.click;
import Extensions.verify;
import Utilities.commonOps;
import WorkFlows.login;
import WorkFlows.search;

@Test
public class shopOnlineTests extends commonOps
{
	
	public void test01_loginError() throws SAXException, ParserConfigurationException, IOException 
	{
		login.loginWithPassword("test@test.com", "ThisIs@T3st");
		verify.textInElement(login.returnLoginError(), "Invalid login or password.");
		
		
	}
	
	public void test02_loginValidate() throws SAXException, ParserConfigurationException, IOException 
	{
		login.loginWithPassword("", "");
		verify.assertCondition(verify.loginValidation());
		
		
	}
	
	public void test03_searchItem() throws SAXException, ParserConfigurationException, IOException
	{
		search.searchByText("shirt", shopMain.autoCompleteShirt);
		click.go(shopResults.oxfortShirt);
	}
	

	public void test04_viewSale () throws SAXException, ParserConfigurationException, IOException
	{
		verify.image("./ImageRepository/slimOxfordShirt.PNG");
	}
}
