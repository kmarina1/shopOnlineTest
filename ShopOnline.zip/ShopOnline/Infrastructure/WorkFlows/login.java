package WorkFlows;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import Extensions.click;
import Extensions.update;
import Utilities.commonOps;

public class login extends commonOps
{
	public static void loginWithPassword (String email, String password) throws SAXException, ParserConfigurationException, IOException
	{
		click.go(shopMain.accountMenu);
		click.go(shopMain.loginDialog);
		
		
		update.text(shopLogin.emailAddress, email);
		click.go(shopLogin.password);
		update.text(shopLogin.password, password);
		click.go(shopLogin.loginButton);
		
		
		
	}
	
	
	public static String returnLoginError () throws SAXException, ParserConfigurationException, IOException
	{
		return shopResults.loginError.getText();
		
		
	}
	public static String returnEmailValidation () throws SAXException, ParserConfigurationException, IOException
	{
		return shopLogin.emailAddress.getText();
		
		
	}
	public static String returnPasswordValidation () throws SAXException, ParserConfigurationException, IOException
	{
		return shopLogin.password.getText();
		
		
	}
}
