package WorkFlows;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.openqa.selenium.WebElement;
import org.xml.sax.SAXException;
import Extensions.click;
import Extensions.update;
import Utilities.commonOps;

public class search extends commonOps
{
	public static void searchByText (String searchValue, WebElement autoComplete) throws SAXException, ParserConfigurationException, IOException
	{
		update.text(shopMain.searchBox, searchValue);
		click.go(autoComplete);
		
		click.go(shopMain.searchButton);
	}
	
}
