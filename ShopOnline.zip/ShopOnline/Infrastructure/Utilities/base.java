package Utilities;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebDriver;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import PageObjects_Wikipedia.loginPage;
import PageObjects_Wikipedia.mainPage;
import PageObjects_Wikipedia.resultsPage;

public class base 
{
public static WebDriver driver;

public static mainPage shopMain;
public static resultsPage shopResults;
public static loginPage shopLogin;

public static Screen screen;

public static ExtentReports extent;
public static ExtentTest test;

public static String timeStamp = new SimpleDateFormat("yyy_MM_dd-HH_mm_ss").format(Calendar.getInstance().getTime());

}

