package Utilities;

import org.openqa.selenium.support.PageFactory;
import PageObjects_Wikipedia.loginPage;
import PageObjects_Wikipedia.mainPage;
import PageObjects_Wikipedia.resultsPage;

public class managePages extends base
{
	public static void init()
	{
		shopMain=PageFactory.initElements(driver, mainPage.class);
		shopResults=PageFactory.initElements(driver, resultsPage.class);
		shopLogin=PageFactory.initElements(driver, loginPage.class);
	}
}
