package Extensions;

import static org.junit.Assert.fail;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.xml.sax.SAXException;

import com.relevantcodes.extentreports.LogStatus;

import Utilities.commonOps;

public class click extends commonOps
{
	public static void go (WebElement elem) throws SAXException, ParserConfigurationException, IOException
	{
		try
		{
			elem.click();
			test.log(LogStatus.PASS,"The element was clicked successfully");
			
		}
		catch (Exception e)
		{
			test.log(LogStatus.FAIL,"Failed to click on the element. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("Failed to click on element");
		}
	}
	
}

