package Extensions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.relevantcodes.extentreports.LogStatus;

import Utilities.commonOps;

public class selectFromMenu  extends commonOps
{
public static void select(WebElement elem, String item)
{
	Select currentSelection = new Select (elem);
	currentSelection.selectByVisibleText(item);
	test.log(LogStatus.PASS,"The item was selected successfully");
}
}
