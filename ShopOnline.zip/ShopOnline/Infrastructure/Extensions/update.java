package Extensions;

import static org.junit.Assert.fail;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.xml.sax.SAXException;

import com.relevantcodes.extentreports.LogStatus;

import Utilities.commonOps;

public class update extends commonOps
{
	public static void text (WebElement elem, String value) throws SAXException, ParserConfigurationException, IOException
	{
		try
		{
			elem.sendKeys(value);
			test.log(LogStatus.PASS,"Text inserted successfully");
		}
		catch (Exception e)
		{
			test.log(LogStatus.FAIL,"Failed to update the text. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("Failed to update the text");
			
		}
	}
	
	public static void dropDownText(WebElement elem, String value) throws SAXException, ParserConfigurationException, IOException
	{
		try
		{
			Select myValue=new Select (elem);
			myValue.selectByVisibleText(value);
			test.log(LogStatus.PASS,"The drop down list was updated successfully");
			
		}
		catch (Exception e)
		{
			test.log(LogStatus.FAIL,"Failed to update the drop down list. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("Failed to update the drop down");
			
		}
		
	}
	
}