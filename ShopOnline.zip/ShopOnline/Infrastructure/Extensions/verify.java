package Extensions;

import org.xml.sax.SAXException;
import com.relevantcodes.extentreports.LogStatus;
import Utilities.commonOps;
import static org.junit.Assert.fail;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;

public class verify extends commonOps

{
	public static void textInElement(String elem, String expectedValue) throws SAXException, ParserConfigurationException, IOException
	{
		
		try
		{
			assertEquals(elem, expectedValue);
			System.out.println("The text Found in Element is: "+elem);
			
		}
		catch (Exception e)
		{
			test.log(LogStatus.FAIL, "Error in finding text. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("Error in finding text. See details: "+e);
		}
		catch (AssertionError e)
		{
			test.log(LogStatus.FAIL, "Text was not found in element. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("The text was not found. See details: "+e);
		}
	}
	public static boolean loginValidation() throws SAXException, ParserConfigurationException, IOException
	{
	
		String emailValue = shopResults.emailValidation.getText();
		String passwordValue = shopResults.passwordValidation.getText();
		
		boolean loginRedStatus=false;
		
		if (emailValue.contains("This is a required field.") && passwordValue.contains("This is a required field.")) 
		{
			loginRedStatus=true;
			test.log(LogStatus.PASS,"The email and password fields were validated successfully");
		} else {
			loginRedStatus=false;
			test.log(LogStatus.FAIL,"Email or password field has not been validated. See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("Failed to update the text");
		}
		return loginRedStatus;
	}
	
	
	public static void assertCondition(boolean condition) throws SAXException, ParserConfigurationException, IOException
	{
		
		try
		{
			assertTrue(condition, "The condition has not been met");
			System.out.println("The condition is: "+condition);
			
		}
		catch (Exception e)
		{
			test.log(LogStatus.FAIL, "Error in finding text. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("Error in finding text. See details: "+e);
		}
		catch (AssertionError e)
		{
			test.log(LogStatus.FAIL, "Text was not found in element. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
			fail("The text was not found. See details: "+e);
		}
	}

	public static void image(String imagePath) throws SAXException, ParserConfigurationException, IOException
	{
			try
		{
			screen.find(imagePath);
			test.log(LogStatus.PASS, "Image found successfully");
		}
			catch(Exception e)
		{
				test.log(LogStatus.FAIL, "Failed to find image. See details: "+e+"See Screenshot: "+test.addScreenCapture(takeSS()));
				fail ("Failed to find image");
		}
			
			
	}
	
}
