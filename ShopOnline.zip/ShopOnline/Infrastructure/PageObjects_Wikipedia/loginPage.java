package PageObjects_Wikipedia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class loginPage 
{
	@FindBy (how=How.ID, using="email")
	public WebElement emailAddress;
	
	@FindBy (how=How.ID, using="pass")
	public WebElement password;
	
	@FindBy (how=How.ID, using="send2")
	public WebElement loginButton;
}
