package PageObjects_Wikipedia;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class resultsPage {

	@FindBy (how=How.CLASS_NAME, using="messages")
	public WebElement loginError;

	@FindBy (how=How.ID, using="advice-required-entry-email")
	public WebElement emailValidation;
	
	@FindBy (how=How.ID, using="advice-required-entry-pass")
	public WebElement passwordValidation;
	
	@FindBy (how=How.ID, using="product-collection-image-403")
	public WebElement oxfortShirt;
	
}
	
	
	
	
	



