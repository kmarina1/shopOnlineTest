package PageObjects_Wikipedia;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class mainPage 
{
@FindBy (how=How.XPATH, using="//*[@id=\"header\"]/div/div[2]/div/a/span[2]")
public WebElement accountMenu;

@FindBy (how=How.LINK_TEXT, using="Log In")
public WebElement loginDialog;
	
	
@FindBy (how=How.ID, using="search")
public WebElement searchBox;

@FindBy (how=How.CSS, using="li[title='shirt']")
public WebElement autoCompleteShirt;

@FindBy (how=How.CLASS_NAME, using="button search-button")
public WebElement searchButton;

@FindBy(how=How.XPATH, using="//*[@id=\"nav\"]/ol/li[5]/a")
public WebElement saleMenu;
}

